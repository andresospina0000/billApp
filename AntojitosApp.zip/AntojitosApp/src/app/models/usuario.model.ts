export class UsuarioModel {

    /**
     * Este modelo emula el comportamiento del formulario de crear nueva cuenta
     */

    email: string;
    password: string;
    nombre: string;

}
