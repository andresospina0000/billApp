export class ClienteModel {

    idCliente: number;
    identifiacion: number;
    nombres: string;
    apellidos: string;

}