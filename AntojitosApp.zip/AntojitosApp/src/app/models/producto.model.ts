export class ProductoModel {

    id: number;
    codigo: string;
    nombre: string;
    valor: number;
    stock: number;
    cantidad: number;
    valorTotal: number;
}